
package com.example.arthurjetpack.data.model

import com.example.arthurjetpack.R

object DataProvider {

    val charcter =
        Charcter(
            id = 1,
            title = "Arthur",
            sex = "Male",
            age = 8,
            description = "The responsible brother' the leader of the team",
            charcterImageId = R.drawable.arthur
        )

    val charcterList = listOf(
        charcter,
        Charcter(
            id = 2,
            title = "Binkey",
            sex = "Male",
            age = 9,
            description = "Bully and dancer, a special person",
            charcterImageId = R.drawable.binkey
        ),
        Charcter(
            id = 3,
            title = "Buster",
            sex = "Male",
            age = 8,
            description = "Best friend of Arthur, the smilest of the team",
            charcterImageId = R.drawable.buster
        ),
        Charcter(
            id = 4,
            title = "Francine",
            sex = "Female",
            age = 8,
            description = " The best sportian of the team, comes from jewish family ",
            charcterImageId = R.drawable.francine
        ),
        Charcter(
            id = 5,
            title = "Fren",
            sex = "Female",
            age = 8,
            description = "Silence with knowledge,mystery researcher",
            charcterImageId = R.drawable.fren
        ),
        Charcter(
            id = 6,
            title = "Fronela",
            sex = "Female",
            age = 8,
            description = "Predicates with a crystal ball the future",
            charcterImageId = R.drawable.fronela
        ),
        Charcter(
            id = 7,
            title = "Ladona",
            sex = "Female",
            age = 9,
            description = "Arthur's neighbord, loves to talk",
            charcterImageId = R.drawable.ladona
        ),
        Charcter(
            id = 8,
            title = "Mofi",
            sex = "Female",
            age = 8,
            description = " Very rich, loves the life ",
            charcterImageId = R.drawable.mofi
        ),
        Charcter(
            id = 9,
            title = "Nemo",
            sex = "Female",
            age = 3,
            description = "Francine's pet, a cat that likes to complain all day",
            charcterImageId = R.drawable.nemo
        ),
        Charcter(
            id = 10,
            title = "Pal",
            sex = "Male",
            age = 3,
            description = "Arthur's pet, beloved and smiling",
            charcterImageId = R.drawable.pal
        ),

    )
}
