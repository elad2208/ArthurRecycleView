package com.example.arthurjetpack

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.arthurjetpack.ui.theme.ArthurJetPackTheme

class MainActivity : AppCompatActivity()  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArthurJetPackTheme {
                MyApp {
                    startActivity(ProfileActivity.newIntent(this, it))
                  }
                }
            }
        }
    }


@Composable
fun MyApp(navigateToProfile: (Character) -> Unit) {
    Scaffold(
        content = {
            ArthurHomeContent(navigateToProfile = navigateToProfile)
        }
    )
}

@Preview("Light Theme", widthDp = 360, heightDp = 640)
@Composable
fun LightPreview() {
    ArthurJetPackTheme{
        MyApp { }
    }
}

@Preview("Dark Theme", widthDp = 360, heightDp = 640)
@Composable
fun DarkPreview() {
    ArthurJetPackTheme(darkTheme = true) {
        MyApp { }
    }
}