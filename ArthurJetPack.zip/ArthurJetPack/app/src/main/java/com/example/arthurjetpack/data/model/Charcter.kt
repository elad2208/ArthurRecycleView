package com.example.arthurjetpack.data.model

import java.io.Serializable

data class Charcter(
    val id: Int,
    val title: String,
    val sex: String,
    val age: Int,
    val description: String,
    val charcterImageId: Int = 0
) : Serializable