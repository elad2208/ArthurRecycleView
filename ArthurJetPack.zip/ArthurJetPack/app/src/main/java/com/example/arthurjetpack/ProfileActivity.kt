package com.example.arthurjetpack

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import com.example.arthurjetpack.data.model.Charcter
import com.example.arthurjetpack.ui.theme.ArthurJetPackTheme

class ProfileActivity : AppCompatActivity() {
    private val charcter: Charcter by lazy {
        intent?.getSerializableExtra(CHARCTER_ID) as Charcter
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArthurJetPackTheme {
                ProfileScreen(charcter)
            }
        }
    }

    companion object {
        private const val CHARCTER_ID = "charcter_id"
        fun newIntent(context: Context, charcter: Character) =
            Intent(context, ProfileActivity::class.java).apply {
                putExtra(CHARCTER_ID, charcter)
            }
    }
}